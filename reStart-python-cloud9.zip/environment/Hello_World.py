print("Hello, World")
