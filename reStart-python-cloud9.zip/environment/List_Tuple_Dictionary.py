#List
myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))

print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])

myFruitList[2] = "orange"
print(myFruitList)


#Tuple
myFinalAnswer = ("apple", "banana", "pinneapple")
print(myFinalAnswer)
print(type(myFinalAnswer))

print(myFinalAnswer[0])
print(myFinalAnswer[1])
print(myFinalAnswer[2])


#Dictionary
myFavoriteFruitDictionary = {
    "Akua" : "apple",
    "Saanvi" : "banana",
    "Paulo" : "pinneapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))

print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])



